#!/usr/bin/env python2.7

""" Script to convert animation timelines from .xar file to .qianim supported by Android-studio Pepper SDK"""

import xmltodict
import os
import json
import math
import string
import argparse
import xml.etree.ElementTree as et

__copyright__ = "Copyright 2018, Softbank Robotics"
__version__ = "1.0.0"

# -------------------
#
#

class QiAnimation():

    def __init__(self):
        self.name = ""
        self.fps = 25
        self.startFrame = 0
        self.endFrame = 0
        self.actuatorCurves = []
        self.hasBehaviorLayerBox = False
        self.output_name = ""

    def __repr__(self):
        return "*%s %sfps %s-%s*" % (self.name, self.fps, self.startFrame, self.endFrame)

    def generateOutpath(self, path, prefix):
        pref = ""
        if prefix :
            pref = "%s_" % prefix

        warn = ""
        if self.hasBehaviorLayerBox :
            warn = "CHECKLAYER_"

        self.output_file = os.path.normpath("%s/%s%s%s.qianim" % (os.path.normpath(path), warn, pref, self.name))


    def toXml(self, path="", prefix=""):
        self.generateOutpath(path, prefix)

        root = et.Element('Animation', {
            'xmlns:editor':"http://www.aldebaran.com/animation/editor",
            'editor:fps':str(self.fps),
            'typeVersion':"2.0"
            })

        for ac in self.actuatorCurves:
            ac.toXml(root, self)

        tree = et.ElementTree(root)
        tree.write(self.output_file, encoding="utf-8", xml_declaration=True, default_namespace=None, method="xml")
        return

class QiActuatorCurve():

    def __init__(self):
        self.actuator = ""
        self.unit = ""
        self.mute = ""
        self.keys = []

    def __repr__(self):
        return "act: %s" % (self.actuator)

    def toXml(self, parent, anim):
        root = et.SubElement(parent, 'ActuatorCurve', {
            'actuator':self.actuator,
            'fps':str(anim.fps),
            'mute':self.mute,
            'unit':self.unit
            })

        for key in self.keys:
            key.toXml(root)

class QiKey():

    def __init__(self):
        self.frame = 0
        self.value = 0
        self.tangents = []

    def toXml(self, parent):
        root = et.SubElement(parent, 'Key', {
            'frame':str(self.frame),
            'value':str(self.value) 
            })

        for tangent in self.tangents:
            tangent.toXml(root)

class QiTangent():

    def __init__(self):
        self.side = ""
        self.type = ""
        self.abscisse = ""
        self.ordinate = ""

    def toXml(self, parent):
        root = et.SubElement(parent, 'Tangent', {
            'abscissaParam':str(self.abscisse),
            'editor:interpType':str(self.type),
            'ordinateParam':str(self.ordinate),
            'side':str(self.side)
            })

UNIT = {
    "0" : "radian",
    "1" : "dimensionless"
} 

BOOLEAN = {
    "0" : "false",
    "1" : "true"
}

IGNORE = ["LAnklePitch", "LAnkleRoll", "LHipPitch", "LHipRoll", "LHipYawPitch", "LKneePitch",
  "RAnklePitch", "RAnkleRoll", "RHipPitch", "RHipRoll", "RHipYawPitch", "RKneePitch" ]

# -------------------
#
#

class XmlToQiAnims():

    def __init__(self, xml_file, out_folder, prefix=""):

        self.qianims = []

        print "opening %s" % xml_file

        def extra_message(anim):
            if anim.hasBehaviorLayerBox:
                return "/!\\ CHECK BEHAVIOR LAYER !!!"
            else:
                return ""

        with open(xml_file, "r") as fd:
            data = xmltodict.parse(fd.read())

            boxes = self._getAnimDict(data)
            qianim = []
            for box in boxes:
                anim = self._animDictToQiAnimation(box)
                self.qianims.append(anim)
                print "-> found animation \"%s\"" % (anim.name)

                anim.toXml(out_folder, prefix)
                print "-> saved as %s %s" % (anim.output_file, extra_message(anim))

    def _getAnimDict(self, data):
        boxes = []        

        for k, v in data.items():
            if k == "Box":
                # we have a box, check if that match the animBox condition
                if isinstance(v, dict):
                    if self._isAnimation(v):
                        boxes.append(v)

                if isinstance(v, list):
                    for i in v :
                        if self._isAnimation(i):
                            boxes.append(i)

            # keep iterating in the tree
            if isinstance(v, dict):
                boxes = boxes + self._getAnimDict(v)

            if isinstance(v, list):
                for i in v :
                    boxes = boxes + self._getAnimDict(i)

        return boxes

    def _isAnimation(self, data):
        # animation are Box[Timeline[ActuatorList[...]]]
        if "Timeline" in data.keys():
            return "ActuatorList" in data["Timeline"]
        return False

    def _hasChildBox(self, data):
        #
        # return True if data has a Box as a child element
        #
        for k, v in data.items():
            if k == "Box":
                return True

            if isinstance(v, dict):
                if self._hasChildBox(v):
                    return True

            if isinstance(v, list):
                for i in v :
                    if self._hasChildBox(i):
                        return True

        return False

    def _get(self, data, key, default=""):
        if key in data.keys():
            return data[key]
        else:
            return default

    def _getAsList(self, data, key, default=[]):
        r = self._get(data, key, default)
        if isinstance(r, list):
            return r
        return [r]

    def _animDictToQiAnimation(self, data):
        anim = QiAnimation()
        anim.name = self._get(data, "@name", "noname")
        self._processTimeline(self._get(data, "Timeline"), anim)

        if self._hasChildBox(data):
            anim.hasBehaviorLayerBox = True

        return anim

    def _processTimeline(self, timeline, anim):
        startFrame = int(self._get(timeline, "@start_frame"))
        endFrame = int(self._get(timeline, "@end_frame"))
        fps = int(self._get(timeline, "@fps"))
        size = int(self._get(timeline, "@size"))

        anim.startFrame = startFrame-1 # index is different in xar and qianim
        anim.endFrame = anim.startFrame + size
        anim.fps = fps

        self._processActuatorList(self._get(timeline, "ActuatorList"), anim)

    def _processActuatorList(self, actuator, anim):
        curves = self._getAsList(actuator, "ActuatorCurve")

        #for curve in self._get(curves, "Key"):
        for curve in curves:
            c = QiActuatorCurve()
            c.actuator = self._get(curve, "@actuator")

            if c.actuator in IGNORE:
                continue

            c.mute = BOOLEAN[self._get(curve, "@mute")]
            c.unit = UNIT[self._get(curve, "@unit")]

            self._processActuatorKeys(self._getAsList(curve, "Key"), c)

            anim.actuatorCurves.append(c)

    def _processActuatorKeys(self, keys, act):
        for key in keys:
            k = QiKey()
            k.frame = int(self._get(key, "@frame"))
            if act.unit == "radian":
                # .xar in degree, qianim in radian
                k.value = math.radians(float(self._get(key, "@value")))
            else:
                k.value = float(self._get(key, "@value"))

            self._processTangent(self._getAsList(key, "Tangent"), k)

            act.keys.append(k)

    def _processTangent(self, tangents, key):
        for tangent in tangents:
            t = QiTangent()
            t.side = self._get(tangent, "@side")
            t.type = self._get(tangent, "@interpType")
            # abscisse is in delta frame, so stay the same
            t.abscisse = self._get(tangent, "@abscissaParam")
            # ordiante is in radian value... so convert from degree
            t.ordinate = str(math.radians(float(self._get(tangent, "@ordinateParam"))))

            key.tangents.append(t)

#---------------------------------------------------------------------------------------------------
#---------------------------------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Convert robot animations in .xar to .qianim')
    parser.add_argument('--xar', '-x', type=str, help='Input file')    
    parser.add_argument('--in', '-i', type=str, help='Input folder')
    parser.add_argument('--out', '-o', type=str, help='Output folder', required=True)
    parser.add_argument('--prefix', '-p', action='store_true', help='Append folder prefix to qianim files')

    args = vars(parser.parse_args())
    file_in = args['xar']
    folder_in = args['in']
    output = args['out']
    prefix_enabled = args['prefix']

    def compute_prefix(prefix_enabled, file):
        if not prefix_enabled:
            return ""
        r = ''.join(s[0].upper() + s[1:] for s in string.split(os.path.dirname(file), '/'))
        return r.replace('.', '').replace('_', '')

    if file_in :
        try:
            convert = XmlToQiAnims(file_in, output, compute_prefix(prefix_enabled, file_in))
        except Exception as e:
            print e

    elif folder_in:
        # start parsing folder
        for root, dirs, files in os.walk(folder_in):
            for name in files:
                if name.endswith('.xar'):
                    xar = os.path.join(root, name)
                    XmlToQiAnims(xar, output, compute_prefix(prefix_enabled, xar))
