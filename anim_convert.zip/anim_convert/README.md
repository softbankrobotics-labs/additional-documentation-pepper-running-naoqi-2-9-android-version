# Anim Converter

This script convert animations in .xar files to .qianim files supported by Android-Studio Pepper SDK.

## Requirement

- Python 2.7
- Module xmltodict (`pip install xmltodict --user`)

## Parameters

- **-h**
Display the help/parameters description
 
- **--xar / -x**
Specify the .xar file to extract animations from.

- **--in / -i**
Specify the root folder to look for .xar, searching recusively into subfolders.

- **--out / -o**
Output folder

- **--prefix / -p**
Output files will be prefixed with the .xar path. Useful if multiples animations share the same name in different behaviors.

## Usage

To extract animations from a single file :
```
python qianim_convert.py -x behavior.xar -o ./out
```

To extract animations from multiple files :
```
python qianim_convert.py -i ./allmyxars/ -o ./out
```

## Note

Converted animations played in the Android-studio animation editor, but sometimes they don't on the robot (you will get an "Optional parameters have a null value" exception).
In that case, just open the animation in Android-studio editor, make any minor change and save. The saved file will now have all necessary parameters setted.
